//Datalibweb system file - do not delete or change
//UDB-L.do

global hhid hhid
global pid pid	
global defmod "D"	
global hhmlist `""D", "H""' 	
global indmlist `""R", "P""' 
global root 
global rootname ECA_Eurostat
global subfolders Data\Harmonized
global data `" "Data\Harmonized" "'
global doc `" "Doc\Questionnaire" "Doc\Technical" "'
global prog `" "Programs" "'
global token 8
global updateday 2
global type UDB-L
global base 
global basedeffile 
global cpi 
global cpifile ANNUAL_ICP_CPI.dta
global cpic SUPPORT
global cpiy 2005
global cpif Data\Stata
global rootcpi ECA
global cpiw 
global cpivarw icp* cpi* 
global distxt ECA TSD/EU-SILC 
global email jmontes@worldbank.org; pcorralrodas@worldbank.org; mnguyen3@worldbank.org

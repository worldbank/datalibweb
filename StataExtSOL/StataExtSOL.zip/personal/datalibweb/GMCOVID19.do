//Datalibweb system file - do not delete or change
//GMCOVID19.do
global hhid hhid
global pid pid
global defmod "ALL"	
global idmod 
global hhmlist 
global indmlist `""ALL""'
global root 
global rootname HFPS-COVID19-Public
global subfolders 
global data `" "Data\Harmonized" "' //one folder
global doc `" "Doc\Questionnaires" "Doc\Technical" "' //can be more than 1 folder
global prog `" "Programs" "'  //can be more than 1 folder
global token 8
global updateday 1
global type GMCOVID19
global base 
global basedeffile
global cpi 
global cpifile 
global cpic SUPPORT
global cpiy 2005
global cpif Data\Stata
global rootcpi 
global cpiw 
global cpivarw 
global distxt Global GMCOVID19
global email datalibweb@worldbank.org;
